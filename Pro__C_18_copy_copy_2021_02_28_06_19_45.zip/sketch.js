var bananaImage;
var obstacleImage;
var obstacleGroup;
var scene;
var backgroundImage;
var score;
var player;
var player_running;
var invisibleGround;
var monkey,monkeyImage;
var foodGroup

function preload() {

  backgroundImage = loadImage("jungle.jpg");
monkeyImage=loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png")

}

function setup() {

  createCanvas(800, 400);

  scene = createSprite(200, 100, 1500, 400);
  scene.addImage("background", backgroundImage);
  scene.x = scene.width / 2;
  scene.velocityX = -2;
  scene.scale=1.5;
  invisibleGround = createSprite(400, 350, 800, 10);
  invisibleGround.visible = false;
  monkey=createSprite(200,350,50,50);
  monkey.addAnimation("running",monkeyImage);
  monkey.scale=0.2;

}

function draw() {

  if (scene.x < 0) {
    scene.x = scene.width / 2;
  }
  
  if(monkey.isTouching(foodGroup)){
    score=score+2;
    foodGroup = destroy;
  }
  
  switch(score){
    case 10: player.scale = 0.12;
      break;
    case 20: player.scale = 0.14;
      break;
    case 30: player.scale = 0.16;
      break;
    case 40: player.scale = 0.18;
      break;
    default: break;
  }
  
  if(obstacleGroup.isTouching(player)){
    player.scale = 0.2
  }
  
  drawSprites();
  
  stroke("white");
  textSize(20);
  fill("white");
  text("score: "+ score, 500, 50);
}